#ifndef TMA_MAPPING_H_
#define TMA_MAPPING_H_

#include <tma/types.h>

namespace tma
{

struct QR
{

  struct interval
  {

  };

  struct triangle
  {

  };

};

} /* namespace tma */

#endif /* TMA_QUADRATURE_H_ */

