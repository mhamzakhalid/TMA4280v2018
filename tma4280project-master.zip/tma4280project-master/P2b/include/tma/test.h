#ifndef TMA_TEST_H_
#define TMA_TEST_H_

#include <tma/types.h>

#include <cstdarg>
#include <cassert>
#include <cstdio>


#define tma_assert(check) assert(check)

namespace tma
{

static void message(char const *fmt, ...)
{
  va_list args;
  va_start(args, fmt);
  vprintf(fmt, args);
  printf("\n");
  va_end(args);
}

} /* namespace tma */

#endif /* TMA_TEST_H_ */
